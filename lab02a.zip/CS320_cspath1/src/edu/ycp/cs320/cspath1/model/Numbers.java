package edu.ycp.cs320.cspath1.model;

public class Numbers {
	private double first, second, third, result;
	
	public Numbers(){
		
	}
	
	public double getFirst(){
		return first;
	}
	
	public double getSecond(){
		return second;
	}
	
	public double getThird(){
		return third;
	}
	
	public double getResult(){
		return result;
	}
	
	public void setFirst(double first){
		this.first = first;
	}
	
	public void setSecond(double second){
		this.second = second;
	}
	
	public void setThird(double third){
		this.third = third;
	}
	public void setResult(double number){
		this.result = number;
	}
}
